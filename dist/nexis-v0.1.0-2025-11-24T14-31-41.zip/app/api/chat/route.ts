import { openai } from "@ai-sdk/openai"
import { convertToModelMessages, stepCountIs, streamText } from "ai"
import { generateImageTool, updateSceneContentTool, updateSceneDetailsTool, addSceneTool, getScenesTool } from "@/lib/ai/tool"
import { qwen } from "@/lib/ai/qwen"
import { getScenes } from "@/app/actions/scenes"
import { kimi } from "@/lib/ai/kimi"

// Allow streaming responses up to 30 seconds
export const maxDuration = 30

export async function POST(req: Request) {
  const { messages, projectId } = await req.json()

  // 获取当前项目信息和场景列表
  let projectContext = ""
  let scenesContext = ""
  
  if (projectId) {
    try {
      // 获取项目信息
      const { db, schema } = await import("@/lib/db/drizzle")
      const { eq } = await import("drizzle-orm")
      const [project] = await db
        .select()
        .from(schema.projects)
        .where(eq(schema.projects.id, projectId))
        .limit(1)
      
      if (project) {
        projectContext = `\n\n当前项目信息：
- 项目名称：${project.title}
- 图片尺寸：${project.imageSize || "1328*1328"}`
      }

      // 获取场景列表
      const scenes = await getScenes(projectId)
      if (scenes.length > 0) {
        scenesContext = "\n\n当前项目的场景列表：\n" + scenes.map((scene, index) => 
          `场景 ${index + 1} (ID: ${scene.id}):
  - 内容: ${scene.content || '(空)'}
  - 镜头编号: ${scene.shot_number || '未设置'}
  - 画面描述: ${scene.frame || '未设置'}
  - 镜头类型: ${scene.shot_type || '未设置'}
  - 时长: ${scene.duration_seconds ? scene.duration_seconds + '秒' : '未设置'}`
        ).join("\n")
      }
    } catch (error) {
      console.error("Failed to fetch project info:", error)
    }
  }

  // 将项目和场景信息添加到系统消息
  const systemMessage = {
    role: "system" as const,
    content: `你是 Nexis AI，一个专业的故事板助手。你可以帮助用户创建、编辑场景和生成图片。

## 当前项目信息
- **项目 ID**: ${projectId || "未设置"}（创建场景时必须使用此 ID）${projectContext}

## 可用工具
1. **getScenes** - 获取当前项目的所有场景信息
   - 使用场景：当你不确定当前有哪些场景时，先调用此工具
   - 返回：所有场景的详细信息（ID、内容、镜头信息等）

2. **addScene** - 添加新场景
   - projectId: 使用上面的项目 ID
   - content: 场景内容描述
   - orderIndex: 场景位置（从0开始）

3. **updateSceneDetails** - 更新场景详细信息
   - sceneId: 场景的真实 UUID
   - 可更新：镜头编号、画面描述、镜头类型、时长、备注等

4. **updateSceneContent** - 更新场景内容
   - sceneId: 场景的真实 UUID
   - content: 新的内容描述

5. **generateImage** - 生成场景图片
   - sceneId: 场景的真实 UUID
   - prompt: 图片生成提示词
   - imageSize: 使用项目设置的尺寸

## 工作流程建议
1. 如果用户要求操作"第一个场景"、"第二个场景"等：
   - 先调用 getScenes 获取场景列表
   - 找到对应位置的场景 ID
   - 使用真实的 UUID 进行操作

2. 如果用户要求创建多个场景：
   - 使用 addScene 逐个创建
   - orderIndex 从当前场景数量开始递增

3. 如果用户要求生成图片：
   - 确保使用场景的真实 UUID（不是 "scene-1" 这样的假 ID）
   - 使用项目设置的图片尺寸

## 重要规则
- ⚠️ 永远不要使用假的 ID（如 "scene-1", "test-project-001"）
- ⚠️ 场景 ID 格式：550e8400-e29b-41d4-a716-446655440000（标准 UUID）
- ⚠️ 不确定场景信息时，先调用 getScenes 工具
- ⚠️ 创建场景时，orderIndex 应该是当前场景数量（从0开始）${scenesContext ? '\n\n## 当前场景' + scenesContext : ''}`
  }

  // const result = streamText({
  //   model: qwen("qwen-plus"),
  //   messages: [systemMessage, ...convertToModelMessages(messages)],
  //   tools: {
  //     getScenes: getScenesTool,
  //     addScene: addSceneTool,
  //     updateSceneDetails: updateSceneDetailsTool,
  //     updateSceneContent: updateSceneContentTool,
  //     generateImage: generateImageTool,
  //   },
  //   stopWhen: stepCountIs(20),
  //   temperature: 0.7,
  // })

  const result = streamText({
    model: kimi("kimi-k2-0905-preview"),
    messages: [systemMessage, ...convertToModelMessages(messages)],
    tools: {
      getScenes: getScenesTool,
      addScene: addSceneTool,
      updateSceneDetails: updateSceneDetailsTool,
      updateSceneContent: updateSceneContentTool,
      generateImage: generateImageTool,
    },
    stopWhen: stepCountIs(20),
    temperature: 0.7,
  })

  return result.toUIMessageStreamResponse()
}
