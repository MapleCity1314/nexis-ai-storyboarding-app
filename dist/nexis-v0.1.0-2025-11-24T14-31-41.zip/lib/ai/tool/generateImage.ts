import { tool } from "ai";
import z from "zod";
import { env } from "@/lib/env";

// 根据阿里云通义万相API扩充参数
const inputSchema = z.object({
  sceneId: z.string().uuid().describe("The UUID of the scene to generate an image for (e.g., 550e8400-e29b-41d4-a716-446655440000)"),
  prompt: z
    .string()
    .max(800)
    .describe("The detailed visual description for the image generation (max 800 characters)"),
  negative_prompt: z
    .string()
    .max(500)
    .optional()
    .describe("Negative prompt to avoid unwanted elements (max 500 characters)"),
  size: z
    .enum(["1328*1328", "1664*928", "1472*1140", "928*1664", "1140*1472"])
    .default("1328*1328")
    .describe("Image resolution"),
  prompt_extend: z
    .boolean()
    .default(true)
    .describe("Enable intelligent prompt enhancement"),
  watermark: z
    .boolean()
    .default(false)
    .describe("Add watermark to the generated image"),
  seed: z
    .number()
    .int()
    .min(0)
    .max(2147483647)
    .optional()
    .describe("Random seed for reproducible results"),
});

// 下载图片并转换为base64
async function downloadImageAsBase64(imageUrl: string): Promise<string> {
  try {
    const response = await fetch(imageUrl);
    if (!response.ok) {
      throw new Error(`Failed to download image: ${response.statusText}`);
    }
    
    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    const base64 = buffer.toString('base64');
    
    // 获取图片类型
    const contentType = response.headers.get('content-type') || 'image/png';
    
    return `data:${contentType};base64,${base64}`;
  } catch (error) {
    console.error('Error downloading image:', error);
    throw error;
  }
}

// 调用阿里云通义万相API生成图片
async function generateImageWithQwen(params: {
  prompt: string;
  negative_prompt?: string;
  size?: string;
  prompt_extend?: boolean;
  watermark?: boolean;
  seed?: number;
}): Promise<string> {
  const apiUrl = 'https://dashscope.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation';
  
  const requestBody = {
    model: "qwen-image-plus", // 推荐使用，性价比更高
    input: {
      messages: [
        {
          role: "user",
          content: [
            {
              text: params.prompt
            }
          ]
        }
      ]
    },
    parameters: {
      negative_prompt: params.negative_prompt || "低分辨率、错误、最差质量",
      prompt_extend: params.prompt_extend ?? true,
      watermark: params.watermark ?? false,
      size: params.size || "1328*1328",
      ...(params.seed !== undefined && { seed: params.seed })
    }
  };

  try {
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${env.QWEN_API_KEY}`
      },
      body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`API request failed: ${response.status} ${response.statusText} - ${errorText}`);
    }

    const result = await response.json();
    
    // 检查响应状态
    if (result.output?.choices?.[0]?.message?.content?.[0]?.image) {
      return result.output.choices[0].message.content[0].image;
    } else {
      throw new Error(`Unexpected API response format: ${JSON.stringify(result)}`);
    }
  } catch (error) {
    console.error('Error calling Qwen Image API:', error);
    throw error;
  }
}

export const generateImageTool = tool({
  description: "Generate an AI image for a specific storyboard scene. Use this when the user wants to create, generate, or visualize an image for a scene. The generated image will be saved to the scene automatically.",
  inputSchema,
  execute: async ({ sceneId, prompt, negative_prompt, size, prompt_extend, watermark, seed }) => {
    try {
      // 1. 调用阿里云通义万相API生成图片
      const imageUrl = await generateImageWithQwen({
        prompt,
        negative_prompt,
        size,
        prompt_extend,
        watermark,
        seed
      });

      // 2. 下载图片并转换为base64
      const base64Image = await downloadImageAsBase64(imageUrl);

      // 3. 保存 base64 图片到数据库
      const { updateScene } = await import("@/app/actions/scenes");
      await updateScene(sceneId, {
        image_url: base64Image,
      } as any);

      // 4. 返回结果
      return {
        success: true,
        sceneId,
        imageUrl: base64Image, // 返回 base64 图片
        message: `✅ 图片已生成并保存到场景 ${sceneId}`
      };
    } catch (error) {
      console.error('Error in generateImageTool:', error);
      return {
        success: false,
        sceneId,
        error: error instanceof Error ? error.message : 'Unknown error occurred',
        message: `❌ 生成图片失败: ${error instanceof Error ? error.message : '未知错误'}`
      };
    }
  }
});