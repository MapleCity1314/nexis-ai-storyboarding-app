# nexis v0.1.0

## 安装说明

1. 解压此文件到目标目录
2. 安装依赖：
   ```bash
   pnpm install
   ```

3. 配置环境变量：
   - 复制 `.env.example` 为 `.env.local`
   - 填写必要的环境变量

4. 运行数据库迁移：
   ```bash
   pnpm db:migrate-scenes
   ```

5. 启动开发服务器：
   ```bash
   pnpm dev
   ```

6. 访问 http://localhost:3000

## 生产部署

1. 构建项目：
   ```bash
   pnpm build
   ```

2. 启动生产服务器：
   ```bash
   pnpm start
   ```

## 文档

- 查看 `HOW_TO_USE_AI.md` 了解 AI 功能使用
- 查看 `FEATURE_COMPLETE.md` 了解所有功能
- 查看 `UI_ENHANCEMENTS_COMPLETE.md` 了解 UI 优化

## 技术栈

- Next.js 16
- React 19
- TypeScript
- Tailwind CSS
- Drizzle ORM
- PostgreSQL
- AI SDK

打包时间: 2025/11/24 22:31:41
