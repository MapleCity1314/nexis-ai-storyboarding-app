"use client"

import { Button } from "@/components/ui/button"
import { useStoryboardStore } from "@/lib/store/storyboard-store"
import ExcelJS from "exceljs"
import { useState } from "react"
import { Loader2 } from "lucide-react"

export function ExportButton() {
  const { project, scenes } = useStoryboardStore()
  const [isExporting, setIsExporting] = useState(false)

  const handleExport = async () => {
    if (!project || scenes.length === 0) return

    setIsExporting(true)

    try {
      const workbook = new ExcelJS.Workbook()
      const worksheet = workbook.addWorksheet("故事板", {
        pageSetup: { paperSize: 9, orientation: "landscape" },
      })

      // 设置列宽
      worksheet.columns = [
        { width: 8 },  // 序号
        { width: 30 }, // 图片
        { width: 12 }, // 镜头编号
        { width: 12 }, // 镜头类型
        { width: 10 }, // 时长
        { width: 35 }, // 画面描述
        { width: 35 }, // 场景内容
        { width: 25 }, // 备注
      ]

      // 添加标题行
      const titleRow = worksheet.addRow([`${project.title} - 故事板`])
      titleRow.height = 30
      titleRow.font = { size: 16, bold: true, color: { argb: "FF000000" } }
      titleRow.alignment = { vertical: "middle", horizontal: "center" }
      worksheet.mergeCells(1, 1, 1, 8)
      titleRow.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FFE0E0E0" },
      }

      // 添加表头
      const headerRow = worksheet.addRow([
        "序号",
        "场景图片",
        "镜头编号",
        "镜头类型",
        "时长(秒)",
        "画面描述",
        "场景内容",
        "备注",
      ])
      headerRow.height = 25
      headerRow.font = { bold: true, size: 11, color: { argb: "FFFFFFFF" } }
      headerRow.alignment = { vertical: "middle", horizontal: "center", wrapText: true }
      headerRow.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF4472C4" },
      }

      // 添加边框样式
      const borderStyle: Partial<ExcelJS.Border> = {
        style: "thin",
        color: { argb: "FF000000" },
      }

      headerRow.eachCell((cell) => {
        cell.border = {
          top: borderStyle,
          left: borderStyle,
          bottom: borderStyle,
          right: borderStyle,
        }
      })

      // 添加场景数据
      for (let i = 0; i < scenes.length; i++) {
        const scene = scenes[i]
        const rowIndex = i + 3 // 从第3行开始（标题+表头）

        // 设置行高（为图片留出空间）
        const row = worksheet.getRow(rowIndex)
        row.height = 120

        // 添加数据
        row.getCell(1).value = i + 1
        row.getCell(3).value = scene.shot_number || "-"
        row.getCell(4).value = scene.shot_type || "-"
        row.getCell(5).value = scene.duration_seconds || "-"
        row.getCell(6).value = scene.frame || "-"
        row.getCell(7).value = scene.content || "-"
        row.getCell(8).value = scene.notes || "-"

        // 设置单元格样式
        row.eachCell((cell, colNumber) => {
          cell.alignment = {
            vertical: "middle",
            horizontal: colNumber === 1 ? "center" : "left",
            wrapText: true,
          }
          cell.border = {
            top: borderStyle,
            left: borderStyle,
            bottom: borderStyle,
            right: borderStyle,
          }
        })

        // 添加图片
        if (scene.image_url) {
          try {
            // 获取图片数据
            const response = await fetch(scene.image_url)
            const blob = await response.blob()
            const arrayBuffer = await blob.arrayBuffer()
            const buffer = Buffer.from(arrayBuffer)

            // 确定图片格式
            let extension: "png" | "jpeg" | "gif" = "png"
            if (scene.image_url.includes(".jpg") || scene.image_url.includes(".jpeg")) {
              extension = "jpeg"
            } else if (scene.image_url.includes(".gif")) {
              extension = "gif"
            }

            // 添加图片到工作簿
            const imageId = workbook.addImage({
              buffer: buffer as any,
              extension: extension,
            })

            // 将图片插入到单元格
            worksheet.addImage(imageId, {
              tl: { col: 1, row: rowIndex - 1 }, // 左上角位置
              ext: { width: 160, height: 110 }, // 图片尺寸
              editAs: "oneCell",
            })
          } catch (error) {
            console.error(`Failed to load image for scene ${i + 1}:`, error)
            row.getCell(2).value = "图片加载失败"
          }
        } else {
          row.getCell(2).value = "无图片"
          row.getCell(2).alignment = { vertical: "middle", horizontal: "center" }
        }
      }

      // 添加页脚信息
      const footerRowIndex = scenes.length + 3
      const footerRow = worksheet.addRow([
        `共 ${scenes.length} 个场景 | 导出时间: ${new Date().toLocaleString("zh-CN")}`,
      ])
      footerRow.font = { size: 9, italic: true, color: { argb: "FF666666" } }
      footerRow.alignment = { vertical: "middle", horizontal: "center" }
      worksheet.mergeCells(footerRowIndex, 1, footerRowIndex, 8)

      // 生成文件
      const buffer = await workbook.xlsx.writeBuffer()
      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      })

      // 下载文件
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement("a")
      link.href = url
      link.download = `${project.title.replace(/\s+/g, "_")}_故事板_${new Date().getTime()}.xlsx`
      link.click()
      window.URL.revokeObjectURL(url)
    } catch (error) {
      console.error("Export failed:", error)
      alert("导出失败，请重试")
    } finally {
      setIsExporting(false)
    }
  }

  return (
    <Button variant="outline" size="sm" onClick={handleExport} disabled={isExporting}>
      {isExporting ? (
        <>
          <Loader2 className="h-4 w-4 animate-spin" />
          导出中...
        </>
      ) : (
        <>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
            <polyline points="7 10 12 15 17 10" />
            <line x1="12" x2="12" y1="15" y2="3" />
          </svg>
          导出故事板
        </>
      )}
    </Button>
  )
}
