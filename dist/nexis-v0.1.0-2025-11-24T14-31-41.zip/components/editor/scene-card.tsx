"use client"

import type { Scene } from "@/types"
import { useStoryboardStore } from "@/lib/store/storyboard-store"
import { Card } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogTrigger, DialogTitle } from "@/components/ui/dialog"
import { VisuallyHidden } from "@/components/ui/visually-hidden"
import { useEffect, useState } from "react"
import { useSortable } from "@dnd-kit/sortable"
import { CSS } from "@dnd-kit/utilities"
import { ChevronRight } from "lucide-react"

interface SceneCardProps {
  scene: Scene
  index: number
}

export function SceneCard({ scene, index }: SceneCardProps) {
  const { updateSceneField, removeScene, saveScene, moveSceneUp, moveSceneDown, scenes } = useStoryboardStore()
  const [content, setContent] = useState(scene.content || "")
  const [isImageDialogOpen, setIsImageDialogOpen] = useState(false)

  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: scene.id,
  })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  }

  const isFirst = index === 1
  const isLast = index === scenes.length

  // Local state for immediate typing feedback
  useEffect(() => {
    setContent(scene.content || "")
  }, [scene.content])

  // Simple debounce implementation for save
  useEffect(() => {
    const timer = setTimeout(() => {
      if (content !== scene.content) {
        updateSceneField(scene.id, "content", content)
        saveScene(scene.id)
      }
    }, 1000)
    return () => clearTimeout(timer)
  }, [content, scene.id, scene.content, updateSceneField, saveScene])

  return (
    <Card ref={setNodeRef} style={style} className="flex flex-col overflow-hidden relative">
      {/* 图片区域 - 固定高度 */}
      <div className="relative h-48 bg-muted flex items-center justify-center group overflow-hidden">
        {scene.image_url ? (
          <Dialog open={isImageDialogOpen} onOpenChange={setIsImageDialogOpen}>
            <DialogTrigger asChild>
              <div className="relative w-full h-full cursor-pointer group">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={scene.image_url}
                  alt={`Scene ${index}`}
                  className="w-full h-full object-cover transition-transform group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity bg-white/90 rounded-full p-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <circle cx="11" cy="11" r="8" />
                      <path d="m21 21-4.3-4.3" />
                      <path d="M11 8v6" />
                      <path d="M8 11h6" />
                    </svg>
                  </div>
                </div>
              </div>
            </DialogTrigger>
            <DialogContent className="max-w-4xl">
              <VisuallyHidden>
                <DialogTitle>场景 {index} 图片</DialogTitle>
              </VisuallyHidden>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={scene.image_url}
                alt={`Scene ${index}`}
                className="w-full h-auto"
              />
            </DialogContent>
          </Dialog>
        ) : (
          <div className="text-muted-foreground text-sm flex flex-col items-center gap-2">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
              <circle cx="9" cy="9" r="2" />
              <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" />
            </svg>
            等待 AI 生成图片
          </div>
        )}

        <div
          className="absolute top-2 left-2 bg-background/80 backdrop-blur px-2 py-0.5 rounded text-xs font-mono font-medium cursor-grab active:cursor-grabbing"
          {...attributes}
          {...listeners}
        >
          SCENE {index}
        </div>

        <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
          <Button
            variant="secondary"
            size="icon"
            className="h-6 w-6"
            onClick={() => moveSceneUp(scene.id)}
            disabled={isFirst}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="12"
              height="12"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="m18 15-6-6-6 6" />
            </svg>
          </Button>
          <Button
            variant="secondary"
            size="icon"
            className="h-6 w-6"
            onClick={() => moveSceneDown(scene.id)}
            disabled={isLast}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="12"
              height="12"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="m6 9 6 6 6-6" />
            </svg>
          </Button>
          <Button variant="destructive" size="icon" className="h-6 w-6" onClick={() => removeScene(scene.id)}>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="12"
              height="12"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M18 6 6 18" />
              <path d="m6 6 12 12" />
            </svg>
          </Button>
        </div>
      </div>

      {/* 场景信息区域 */}
      <div className="p-4 flex-1 flex flex-col gap-3">
        {/* 分镜详细信息 */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          {scene.shot_number && (
            <div className="flex items-center gap-1">
              <span className="text-muted-foreground">编号:</span>
              <span className="font-medium">{scene.shot_number}</span>
            </div>
          )}
          {scene.shot_type && (
            <div className="flex items-center gap-1">
              <span className="text-muted-foreground">类型:</span>
              <span className="font-medium">{scene.shot_type}</span>
            </div>
          )}
          {scene.duration_seconds && (
            <div className="flex items-center gap-1">
              <span className="text-muted-foreground">时长:</span>
              <span className="font-medium">{scene.duration_seconds}秒</span>
            </div>
          )}
        </div>

        {/* 画面描述 */}
        {scene.frame && (
          <div className="text-xs">
            <span className="text-muted-foreground">画面: </span>
            <span className="text-foreground">{scene.frame}</span>
          </div>
        )}

        {/* 场景内容 */}
        <Textarea
          placeholder="描述这个场景发生的画面、动作或对白..."
          className="resize-none min-h-[80px] text-sm border-0 focus-visible:ring-0 px-0 shadow-none bg-transparent"
          value={content}
          onChange={(e) => setContent(e.target.value)}
        />

        {/* 备注 */}
        {scene.notes && (
          <div className="text-xs text-muted-foreground bg-muted/50 p-2 rounded">
            <span className="font-semibold">备注:</span> {scene.notes}
          </div>
        )}

        {/* AI 思考 */}
        {scene.ai_notes && (
          <div className="text-xs text-muted-foreground bg-primary/5 p-2 rounded border border-primary/10">
            <span className="font-semibold text-primary/70">AI 思考:</span> {scene.ai_notes}
          </div>
        )}
      </div>

      {/* 时间方向指引 - 不是最后一个场景时显示 */}
      {!isLast && (
        <div className="absolute -right-4 top-1/2 -translate-y-1/2 z-10">
          <div className="bg-primary text-primary-foreground rounded-full p-1 shadow-lg">
            <ChevronRight className="h-4 w-4" />
          </div>
        </div>
      )}
    </Card>
  )
}
