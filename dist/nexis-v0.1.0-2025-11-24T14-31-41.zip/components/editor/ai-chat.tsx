"use client"

import { useChat } from "@ai-sdk/react"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useStoryboardStore } from "@/lib/store/storyboard-store"
import { useEffect, useRef } from "react"
import { Loader2, Send, StopCircle } from "lucide-react"
import { DefaultChatTransport } from "ai"
import { AiMessage } from "./ai-message"
import { AiInput } from "./ai-input"
import { Button } from "../ui/button"
import { cn } from "@/lib/utils"
import ReactMarkdown from "react-markdown"

interface AiChatProps {
  projectId: string
}

function generateUUID() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`
}

// 自动发送条件：最后一条助手消息完成且包含工具调用
function lastAssistantMessageIsCompleteWithToolCalls(message: any) {
  return (
    message.role === "assistant" &&
    message.status === "complete" &&
    message.toolInvocations &&
    message.toolInvocations.length > 0
  )
}

export function AiChat({ projectId }: AiChatProps) {
  const { refreshScenes, setGeneratingImage } = useStoryboardStore()
  const scrollRef = useRef<HTMLDivElement>(null)

  const {
    messages,
    sendMessage,
    status,
    stop,
    addToolResult,
  } = useChat({
    id: projectId,
    generateId: generateUUID,
    transport: new DefaultChatTransport({
      api: "/api/chat",
      body: () => ({
        projectId,
      }),
    }),
    sendAutomaticallyWhen: lastAssistantMessageIsCompleteWithToolCalls,
    // 工具调用回显处理
    async onToolCall({ toolCall }) {
      console.log("[Client Side] 前端发生工具调用回显")

      if (toolCall.dynamic) {
        console.log("[Client Side] 前端发生动态工具调用回显，但并不处理")
        return
      }

      // 处理工具调用回显
      await handleToolCall(toolCall)
    },
  })

  // 处理工具调用
  const handleToolCall = async (toolCall: any) => {
    const toolName = toolCall.toolName
    const args = (toolCall as any).args || {}
    console.log("[Client Side] 处理工具调用:", toolName, args)

    // 为不同工具添加回显
    switch (toolName) {
      case "getScenes":
        await handleGetScenesTool(toolCall)
        break
      case "generateImage":
        await handleGenerateImageTool(toolCall)
        break
      case "updateSceneContent":
        await handleUpdateSceneContentTool(toolCall)
        break
      case "updateSceneDetails":
        await handleUpdateSceneDetailsTool(toolCall)
        break
      case "addScene":
        await handleAddSceneTool(toolCall)
        break
      default:
        console.log("[Client Side] 未知工具调用:", toolName)
    }
  }

  // 获取场景列表工具回显
  const handleGetScenesTool = async (toolCall: any) => {
    console.log("[Client Side] 处理获取场景列表工具调用")
    const args = (toolCall as any).args || {}

    addToolResult({
      toolCallId: toolCall.toolCallId,
      tool: toolCall.toolName,
      output: {
        status: "processing",
        message: `📋 正在获取场景列表\n\n项目ID：${args.projectId}`,
      },
    })
  }

  // 生成图片工具回显
  const handleGenerateImageTool = async (toolCall: any) => {
    console.log("[Client Side] 处理生成图片工具调用")
    const args = (toolCall as any).args || {}
    
    // 设置生成状态
    setGeneratingImage(args.sceneId)

    addToolResult({
      toolCallId: toolCall.toolCallId,
      tool: toolCall.toolName,
      output: {
        status: "processing",
        message: `🎨 正在生成图片\n\n场景ID：${args.sceneId}\n提示词：${args.prompt}\n\n⏳ 这可能需要几分钟时间，请耐心等待...`,
      },
    })
  }

  // 更新场景内容工具回显
  const handleUpdateSceneContentTool = async (toolCall: any) => {
    console.log("[Client Side] 处理更新场景内容工具调用")
    const args = (toolCall as any).args || {}

    addToolResult({
      toolCallId: toolCall.toolCallId,
      tool: toolCall.toolName,
      output: {
        status: "processing",
        message: `✏️ 正在更新场景内容\n\n场景ID：${args.sceneId}\n新内容：${args.content}`,
      },
    })
  }

  // 更新场景详细信息工具回显
  const handleUpdateSceneDetailsTool = async (toolCall: any) => {
    console.log("[Client Side] 处理更新场景详细信息工具调用")
    const args = (toolCall as any).args || {}

    const updates = []
    if (args.shotNumber) updates.push(`镜头编号: ${args.shotNumber}`)
    if (args.frame) updates.push(`画面: ${args.frame}`)
    if (args.shotType) updates.push(`镜头类型: ${args.shotType}`)
    if (args.durationSeconds) updates.push(`时长: ${args.durationSeconds}秒`)
    if (args.content) updates.push(`内容: ${args.content}`)
    if (args.notes) updates.push(`备注: ${args.notes}`)

    addToolResult({
      toolCallId: toolCall.toolCallId,
      tool: toolCall.toolName,
      output: {
        status: "processing",
        message: `🎬 正在更新场景详细信息\n\n${updates.join('\n')}`,
      },
    })
  }

  // 添加场景工具回显
  const handleAddSceneTool = async (toolCall: any) => {
    console.log("[Client Side] 处理添加场景工具调用")
    const args = (toolCall as any).args || {}

    addToolResult({
      toolCallId: toolCall.toolCallId,
      tool: toolCall.toolName,
      output: {
        status: "processing",
        message: `➕ 正在添加新场景\n\n内容：${args.content}\n位置：第 ${args.orderIndex + 1} 个`,
      },
    })
  }



  // 自动滚动到底部
  useEffect(() => {
    if (scrollRef.current) {
      // ScrollArea 的实际滚动容器是 viewport
      const viewport = scrollRef.current.querySelector('[data-radix-scroll-area-viewport]')
      if (viewport) {
        viewport.scrollTop = viewport.scrollHeight
      }
    }
  }, [messages])

  // 监听消息变化，当有新的工具输出时刷新场景
  useEffect(() => {
    const lastMessage = messages[messages.length - 1]
    if (lastMessage?.role === "assistant" && lastMessage?.parts) {
      const hasCompletedTool = lastMessage.parts.some(
        (part: any) =>
          part.type?.startsWith("tool-") && part.state === "output-available"
      )
      if (hasCompletedTool) {
        refreshScenes()
      }
    }
  }, [messages, refreshScenes])

  const handleSubmit = async (userMessage: string) => {
    await sendMessage({
      role: "user",
      parts: [{ type: "text", text: userMessage }],
    })
  }

  const isLoading = status === "streaming"

  return (
    <div className="flex h-full flex-col border-l bg-card w-96">
      {/* Header */}
      <div className="border-b p-4 bg-linear-to-r from-primary/10 to-primary/5">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-primary"
            >
              <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z" />
              <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
              <line x1="12" x2="12" y1="19" y2="22" />
            </svg>
          </div>
          <div>
            <h3 className="font-semibold">Nexis AI</h3>
            <p className="text-xs text-muted-foreground">智能故事板助手</p>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-hidden">
        <ScrollArea className="h-full p-4" ref={scrollRef}>
          <div className="space-y-4 pr-4">
          {messages.length === 0 && (
            <div className="text-center text-sm text-muted-foreground py-8 space-y-4">
              <div className="text-base font-medium text-foreground">👋 你好！我能帮你：</div>
              <div className="space-y-2 text-left max-w-xs mx-auto">
                <div className="p-3 bg-muted rounded-lg">
                  💡 "帮我生成第一个场景的图片"
                </div>
                <div className="p-3 bg-muted rounded-lg">
                  ✏️ "修改第二个场景的内容"
                </div>
                <div className="p-3 bg-muted rounded-lg">
                  ➕ "添加一个新的场景"
                </div>
              </div>
            </div>
          )}

          {messages.map((m: any) => (
            <AiMessage key={m.id} message={m} isLoading={isLoading && messages[messages.length - 1]?.id === m.id} />
          ))}

          {isLoading && messages[messages.length - 1]?.role === "user" && (
            <div className="flex gap-2 p-3 text-sm bg-muted mr-8 rounded-lg">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>AI 正在思考...</span>
            </div>
          )}
          </div>
        </ScrollArea>
      </div>

      {/* Input */}
      <AiInput onSubmit={handleSubmit} onStop={stop} isLoading={isLoading} />
    </div>
  )
}
