"use client"

import { useState } from "react"
import { Loader2, ChevronDown, ChevronUp } from "lucide-react"
import ReactMarkdown from "react-markdown"
import { cn } from "@/lib/utils"

interface AiMessageProps {
  message: any
  isLoading: boolean
}

export function AiMessage({ message, isLoading }: AiMessageProps) {
  const [collapsedTools, setCollapsedTools] = useState<Set<number>>(new Set())

  const toggleToolCollapse = (index: number) => {
    setCollapsedTools((prev) => {
      const next = new Set(prev)
      if (next.has(index)) {
        next.delete(index)
      } else {
        next.add(index)
      }
      return next
    })
  }

  // 获取工具调用的显示消息
  const getToolCallDisplayMessage = (toolName: string, args: any): string => {
    switch (toolName) {
      case "getScenes":
        return `📋 获取场景列表`
      case "generateImage":
        return `🎨 生成图片`
      case "updateSceneDetails":
        return `🎬 更新场景详细信息`
      case "updateSceneContent":
        return `✏️ 更新场景内容`
      case "addScene":
        return `➕ 添加新场景`
      default:
        return `🔧 执行工具：${toolName}`
    }
  }

  // 获取工具状态图标
  const getToolStatusIcon = (state: string) => {
    switch (state) {
      case "input-streaming":
      case "input-available":
        return <Loader2 className="h-3 w-3 animate-spin text-blue-500" />
      case "output-available":
        return (
          <svg
            className="h-3 w-3 text-green-500"
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <polyline points="20 6 9 17 4 12" />
          </svg>
        )
      case "output-error":
        return (
          <svg
            className="h-3 w-3 text-red-500"
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <circle cx="12" cy="12" r="10" />
            <line x1="15" y1="9" x2="9" y2="15" />
            <line x1="9" y1="9" x2="15" y2="15" />
          </svg>
        )
      default:
        return null
    }
  }

  return (
    <div
      className={cn(
        "flex flex-col gap-2 rounded-lg p-3 text-sm transition-all animate-in fade-in slide-in-from-bottom-2",
        message.role === "user"
          ? "bg-primary text-primary-foreground ml-8 shadow-sm"
          : "bg-muted mr-8"
      )}
    >
      <div className="flex items-center gap-2">
        <span className="font-semibold text-xs opacity-70">
          {message.role === "user" ? "你" : "AI"}
        </span>
        {message.role === "assistant" && isLoading && (
          <Loader2 className="h-3 w-3 animate-spin" />
        )}
      </div>

      {/* Message parts */}
      {message.parts && message.parts.length > 0 && (
        <div className="space-y-2">
          {message.parts.map((part: any, index: number) => (
            <div key={index}>
              {/* Text part */}
              {part.type === "text" && (
                <div className="prose prose-sm dark:prose-invert max-w-none whitespace-pre-wrap">
                  <ReactMarkdown>{part.text}</ReactMarkdown>
                  {part.state === "streaming" && (
                    <span className="inline-block w-2 h-4 bg-current animate-pulse ml-1" />
                  )}
                </div>
              )}

              {/* Reasoning part */}
              {part.type === "reasoning" && (
                <div className="text-xs bg-blue-500/10 text-blue-600 dark:text-blue-400 p-2 rounded border border-blue-500/20">
                  <div className="font-semibold mb-1">🤔 思考过程</div>
                  <div className="whitespace-pre-wrap">{part.text}</div>
                </div>
              )}

              {/* Tool parts - 增强版 */}
              {part.type?.startsWith("tool-") && (
                <div
                  className={cn(
                    "text-xs rounded border transition-all",
                    part.state === "output-available" && collapsedTools.has(index)
                      ? "bg-muted/30 border-muted"
                      : "bg-gradient-to-r from-primary/5 to-primary/10 border-primary/20"
                  )}
                >
                  {/* 工具头部 - 可折叠 */}
                  {part.state === "output-available" ? (
                    <button
                      onClick={() => toggleToolCollapse(index)}
                      className="w-full flex items-center justify-between p-2 hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        {getToolStatusIcon(part.state)}
                        <span className="font-medium">
                          {getToolCallDisplayMessage(
                            part.type.replace("tool-", ""),
                            part.input
                          )}
                        </span>
                        <span className="text-green-600 dark:text-green-400">完成</span>
                      </div>
                      {collapsedTools.has(index) ? (
                        <ChevronDown className="h-3 w-3" />
                      ) : (
                        <ChevronUp className="h-3 w-3" />
                      )}
                    </button>
                  ) : (
                    <div className="flex items-center gap-2 p-2">
                      {getToolStatusIcon(part.state)}
                      <span className="font-medium">
                        {getToolCallDisplayMessage(
                          part.type.replace("tool-", ""),
                          part.input
                        )}
                      </span>
                      {part.state === "input-streaming" && (
                        <span className="text-muted-foreground">准备中...</span>
                      )}
                      {part.state === "input-available" && (
                        <span className="text-blue-600 dark:text-blue-400">执行中...</span>
                      )}
                    </div>
                  )}

                  {/* 工具内容 - 可折叠 */}
                  {!collapsedTools.has(index) && (
                    <div className="px-2 pb-2 space-y-1">
                      {part.state === "output-available" && (
                        <div className="whitespace-pre-wrap text-muted-foreground">
                          {typeof part.output === "object" && part.output?.message
                            ? part.output.message
                            : JSON.stringify(part.output, null, 2)}
                        </div>
                      )}

                      {part.state === "output-error" && (
                        <div className="text-red-600 dark:text-red-400">
                          ❌ 工具执行失败: {part.errorText}
                        </div>
                      )}
                    </div>
                  )}

                  {/* 光流动画 */}
                  {(part.state === "input-streaming" || part.state === "input-available") && (
                    <div className="h-0.5 w-full bg-gradient-to-r from-transparent via-primary to-transparent animate-shimmer" />
                  )}
                </div>
              )}

              {/* File part */}
              {part.type === "file" && (
                <div className="flex items-center gap-2 p-2 bg-muted rounded border">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
                    <polyline points="14 2 14 8 20 8" />
                  </svg>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium truncate">
                      {part.filename || "文件"}
                    </div>
                    <div className="text-xs text-muted-foreground">{part.mediaType}</div>
                  </div>
                </div>
              )}

              {/* Source URL part */}
              {part.type === "source-url" && (
                <div className="text-xs p-2 bg-muted rounded border">
                  <div className="font-semibold">🔗 来源</div>
                  <a
                    href={part.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-primary hover:underline"
                  >
                    {part.title || part.url}
                  </a>
                </div>
              )}

              {/* Step start part */}
              {part.type === "step-start" && (
                <div className="text-xs text-muted-foreground border-t pt-2 mt-2 flex items-center gap-2">
                  <div className="h-px flex-1 bg-gradient-to-r from-transparent via-border to-transparent" />
                  <span>新步骤</span>
                  <div className="h-px flex-1 bg-gradient-to-r from-transparent via-border to-transparent" />
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
