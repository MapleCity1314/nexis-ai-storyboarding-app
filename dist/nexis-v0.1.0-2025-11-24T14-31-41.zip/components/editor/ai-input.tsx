"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Send, StopCircle } from "lucide-react"

interface AiInputProps {
  onSubmit: (message: string) => void
  onStop: () => void
  isLoading: boolean
}

export function AiInput({ onSubmit, onStop, isLoading }: AiInputProps) {
  const [input, setInput] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return

    onSubmit(input.trim())
    setInput("")
  }

  return (
    <div className="border-t p-4 bg-muted/30">
      <form onSubmit={handleSubmit} className="flex gap-2 items-end">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault()
              handleSubmit(e as any)
            }
          }}
          placeholder={isLoading ? "AI 正在处理..." : "输入指令..."}
          className="flex-1 min-h-[40px] max-h-[200px] resize-none rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
          disabled={isLoading}
          autoFocus
          rows={1}
          style={{
            height: "auto",
            minHeight: "40px",
          }}
          onInput={(e) => {
            const target = e.target as HTMLTextAreaElement
            target.style.height = "auto"
            target.style.height = Math.min(target.scrollHeight, 200) + "px"
          }}
        />
        {isLoading ? (
          <Button
            type="button"
            size="icon"
            variant="destructive"
            onClick={onStop}
            title="停止生成"
          >
            <StopCircle className="h-4 w-4" />
          </Button>
        ) : (
          <Button type="submit" size="icon" disabled={!input.trim()} title="发送消息">
            <Send className="h-4 w-4" />
          </Button>
        )}
      </form>
      <p className="text-xs text-muted-foreground mt-2 text-center">
        按 Enter 发送，Shift + Enter 换行
      </p>
    </div>
  )
}
