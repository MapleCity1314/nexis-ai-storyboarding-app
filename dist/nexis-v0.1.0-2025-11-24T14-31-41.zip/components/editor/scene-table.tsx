"use client"

import type { Scene } from "@/types"
import { useStoryboardStore } from "@/lib/store/storyboard-store"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useState, useEffect } from "react"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"

export function SceneTable() {
  const { scenes, updateSceneField, saveScene, removeScene, moveSceneUp, moveSceneDown } = useStoryboardStore()
  const [editingCell, setEditingCell] = useState<{ sceneId: string; field: string } | null>(null)
  const [editValue, setEditValue] = useState("")

  const handleCellClick = (sceneId: string, field: keyof Scene, value: any) => {
    setEditingCell({ sceneId, field })
    setEditValue(value?.toString() || "")
  }

  const handleCellBlur = async (sceneId: string, field: keyof Scene) => {
    if (editingCell?.sceneId === sceneId && editingCell?.field === field) {
      const scene = scenes.find((s) => s.id === sceneId)
      if (scene && editValue !== scene[field]?.toString()) {
        updateSceneField(sceneId, field, editValue)
        await saveScene(sceneId)
      }
      setEditingCell(null)
    }
  }

  const handleImageUpload = async (sceneId: string, file: File) => {
    // 这里应该实现图片上传逻辑
    // 暂时使用本地预览
    const reader = new FileReader()
    reader.onload = (e) => {
      const imageUrl = e.target?.result as string
      updateSceneField(sceneId, "image_url", imageUrl)
      saveScene(sceneId)
    }
    reader.readAsDataURL(file)
  }

  return (
    <div className="w-full overflow-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[60px]">序号</TableHead>
            <TableHead className="w-[100px]">镜头编号</TableHead>
            <TableHead className="w-[150px]">图片</TableHead>
            <TableHead className="w-[120px]">镜头类型</TableHead>
            <TableHead className="min-w-[200px]">画面描述</TableHead>
            <TableHead className="min-w-[200px]">场景内容</TableHead>
            <TableHead className="w-[100px]">时长(秒)</TableHead>
            <TableHead className="min-w-[150px]">备注</TableHead>
            <TableHead className="w-[120px]">操作</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {scenes.map((scene, index) => (
            <TableRow key={scene.id}>
              <TableCell className="font-mono text-xs">{index + 1}</TableCell>
              
              <TableCell>
                {editingCell?.sceneId === scene.id && editingCell?.field === "shot_number" ? (
                  <Input
                    value={editValue}
                    onChange={(e) => setEditValue(e.target.value)}
                    onBlur={() => handleCellBlur(scene.id, "shot_number")}
                    autoFocus
                    className="h-8"
                  />
                ) : (
                  <div
                    className="cursor-pointer hover:bg-muted/50 p-1 rounded min-h-[32px]"
                    onClick={() => handleCellClick(scene.id, "shot_number", scene.shot_number)}
                  >
                    {scene.shot_number || "-"}
                  </div>
                )}
              </TableCell>

              <TableCell>
                <div className="flex flex-col gap-2">
                  {scene.image_url ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={scene.image_url}
                      alt={`Scene ${index + 1}`}
                      className="w-20 h-20 object-cover rounded"
                    />
                  ) : (
                    <div className="w-20 h-20 bg-muted rounded flex items-center justify-center text-xs text-muted-foreground">
                      无图片
                    </div>
                  )}
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0]
                      if (file) handleImageUpload(scene.id, file)
                    }}
                    className="h-8 text-xs"
                  />
                </div>
              </TableCell>

              <TableCell>
                {editingCell?.sceneId === scene.id && editingCell?.field === "shot_type" ? (
                  <Input
                    value={editValue}
                    onChange={(e) => setEditValue(e.target.value)}
                    onBlur={() => handleCellBlur(scene.id, "shot_type")}
                    autoFocus
                    className="h-8"
                  />
                ) : (
                  <div
                    className="cursor-pointer hover:bg-muted/50 p-1 rounded min-h-[32px]"
                    onClick={() => handleCellClick(scene.id, "shot_type", scene.shot_type)}
                  >
                    {scene.shot_type || "-"}
                  </div>
                )}
              </TableCell>

              <TableCell>
                {editingCell?.sceneId === scene.id && editingCell?.field === "frame" ? (
                  <Textarea
                    value={editValue}
                    onChange={(e) => setEditValue(e.target.value)}
                    onBlur={() => handleCellBlur(scene.id, "frame")}
                    autoFocus
                    className="min-h-[60px]"
                  />
                ) : (
                  <div
                    className="cursor-pointer hover:bg-muted/50 p-1 rounded min-h-[32px] text-sm"
                    onClick={() => handleCellClick(scene.id, "frame", scene.frame)}
                  >
                    {scene.frame || "-"}
                  </div>
                )}
              </TableCell>

              <TableCell>
                {editingCell?.sceneId === scene.id && editingCell?.field === "content" ? (
                  <Textarea
                    value={editValue}
                    onChange={(e) => setEditValue(e.target.value)}
                    onBlur={() => handleCellBlur(scene.id, "content")}
                    autoFocus
                    className="min-h-[60px]"
                  />
                ) : (
                  <div
                    className="cursor-pointer hover:bg-muted/50 p-1 rounded min-h-[32px] text-sm"
                    onClick={() => handleCellClick(scene.id, "content", scene.content)}
                  >
                    {scene.content || "-"}
                  </div>
                )}
              </TableCell>

              <TableCell>
                {editingCell?.sceneId === scene.id && editingCell?.field === "duration_seconds" ? (
                  <Input
                    type="number"
                    value={editValue}
                    onChange={(e) => setEditValue(e.target.value)}
                    onBlur={() => handleCellBlur(scene.id, "duration_seconds")}
                    autoFocus
                    className="h-8"
                  />
                ) : (
                  <div
                    className="cursor-pointer hover:bg-muted/50 p-1 rounded min-h-[32px]"
                    onClick={() => handleCellClick(scene.id, "duration_seconds", scene.duration_seconds)}
                  >
                    {scene.duration_seconds || "-"}
                  </div>
                )}
              </TableCell>

              <TableCell>
                <div className="flex flex-col gap-2">
                  {scene.image_url ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={scene.image_url}
                      alt={`Scene ${index + 1}`}
                      className="w-20 h-20 object-cover rounded"
                    />
                  ) : (
                    <div className="w-20 h-20 bg-muted rounded flex items-center justify-center text-xs text-muted-foreground">
                      无图片
                    </div>
                  )}
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0]
                      if (file) handleImageUpload(scene.id, file)
                    }}
                    className="h-8 text-xs"
                  />
                </div>
              </TableCell>

              <TableCell>
                {editingCell?.sceneId === scene.id && editingCell?.field === "notes" ? (
                  <Textarea
                    value={editValue}
                    onChange={(e) => setEditValue(e.target.value)}
                    onBlur={() => handleCellBlur(scene.id, "notes")}
                    autoFocus
                    className="min-h-[60px]"
                  />
                ) : (
                  <div
                    className="cursor-pointer hover:bg-muted/50 p-1 rounded min-h-[32px] text-sm"
                    onClick={() => handleCellClick(scene.id, "notes", scene.notes)}
                  >
                    {scene.notes || "-"}
                  </div>
                )}
              </TableCell>

              <TableCell>
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => moveSceneUp(scene.id)}
                    disabled={index === 0}
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="14"
                      height="14"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="m18 15-6-6-6 6" />
                    </svg>
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => moveSceneDown(scene.id)}
                    disabled={index === scenes.length - 1}
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="14"
                      height="14"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="m6 9 6 6 6-6" />
                    </svg>
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-destructive"
                    onClick={() => removeScene(scene.id)}
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="14"
                      height="14"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M18 6 6 18" />
                      <path d="m6 6 12 12" />
                    </svg>
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>

      {scenes.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <div className="rounded-full bg-muted p-6 mb-4">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="32"
              height="32"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-muted-foreground"
            >
              <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
              <polyline points="14 2 14 8 20 8" />
            </svg>
          </div>
          <h3 className="text-lg font-semibold mb-2">暂无场景</h3>
          <p className="text-muted-foreground">点击右上角的"添加场景"开始创作</p>
        </div>
      )}
    </div>
  )
}
