"use client"

import { formatDistanceToNow } from "date-fns"
import { zhCN } from "date-fns/locale"
import { RefreshCw, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { restoreProject, permanentDeleteProject } from "@/app/actions/projects"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

interface Project {
  id: string
  title: string
  description: string | null
  deleted_at: string
}

export function TrashList({ projects }: { projects: Project[] }) {
  if (projects.length === 0) {
    return (
      <div className="flex h-[450px] shrink-0 items-center justify-center rounded-md border border-dashed">
        <div className="mx-auto flex max-w-[420px] flex-col items-center justify-center text-center">
          <h3 className="mt-4 text-lg font-semibold">回收站为空</h3>
          <p className="mb-4 mt-2 text-sm text-muted-foreground">没有被删除的项目。</p>
        </div>
      </div>
    )
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      {projects.map((project) => (
        <Card key={project.id} className="opacity-75 hover:opacity-100 transition-opacity">
          <CardHeader>
            <CardTitle className="text-base font-semibold leading-none tracking-tight truncate">
              {project.title}
            </CardTitle>
            <CardDescription className="line-clamp-2 text-xs">{project.description || "无描述"}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="aspect-video w-full rounded-md bg-muted/50 flex items-center justify-center text-muted-foreground text-xs">
              已删除
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <p className="text-xs text-muted-foreground">
              删除于 {formatDistanceToNow(new Date(project.deleted_at), { addSuffix: true, locale: zhCN })}
            </p>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8 bg-transparent"
                onClick={() => restoreProject(project.id)}
              >
                <RefreshCw className="h-4 w-4" />
                <span className="sr-only">恢复</span>
              </Button>
              <Button
                variant="destructive"
                size="icon"
                className="h-8 w-8"
                onClick={() => permanentDeleteProject(project.id)}
              >
                <Trash2 className="h-4 w-4" />
                <span className="sr-only">永久删除</span>
              </Button>
            </div>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}
