import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { RotateCcw, Trash2 } from "lucide-react"
import { restoreProject, permanentDeleteProject } from "@/app/actions/projects"
import type { Project } from "@/lib/db/schema"

interface TrashProjectCardProps {
  project: Project
}

export function TrashProjectCard({ project }: TrashProjectCardProps) {
  async function handleRestore() {
    await restoreProject(project.id)
  }

  async function handlePermanentDelete() {
    if (confirm("确定要永久删除此项目吗？此操作无法撤销！")) {
      await permanentDeleteProject(project.id)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{project.title}</CardTitle>
        {project.description && (
          <CardDescription className="line-clamp-2">
            {project.description}
          </CardDescription>
        )}
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-sm text-muted-foreground">
          删除于 {project.deletedAt ? new Date(project.deletedAt).toLocaleDateString('zh-CN') : '未知'}
        </p>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleRestore}
            className="flex-1"
          >
            <RotateCcw className="mr-2 h-4 w-4" />
            恢复
          </Button>
          <Button
            variant="destructive"
            size="sm"
            onClick={handlePermanentDelete}
            className="flex-1"
          >
            <Trash2 className="mr-2 h-4 w-4" />
            永久删除
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
