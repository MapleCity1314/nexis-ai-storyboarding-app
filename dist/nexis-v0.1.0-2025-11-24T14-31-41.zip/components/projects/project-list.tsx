"use client"

import Link from "next/link"
import { formatDistanceToNow } from "date-fns"
import { zhCN } from "date-fns/locale"
import { MoreHorizontal, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { deleteProject } from "@/app/actions/projects"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

interface Project {
  id: string
  title: string
  description: string | null
  updated_at: string
}

export function ProjectList({ projects }: { projects: Project[] }) {
  if (projects.length === 0) {
    return (
      <div className="flex h-[450px] shrink-0 items-center justify-center rounded-md border border-dashed">
        <div className="mx-auto flex max-w-[420px] flex-col items-center justify-center text-center">
          <h3 className="mt-4 text-lg font-semibold">没有项目</h3>
          <p className="mb-4 mt-2 text-sm text-muted-foreground">您还没有创建任何项目。点击上方按钮开始创建。</p>
        </div>
      </div>
    )
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      {projects.map((project) => (
        <Card key={project.id} className="group relative transition-all hover:shadow-md">
          <Link href={`/editor/${project.id}`} className="absolute inset-0 z-0" prefetch={false}>
            <span className="sr-only">查看项目</span>
          </Link>
          <CardHeader>
            <div className="flex items-start justify-between space-y-0">
              <CardTitle className="text-base font-semibold leading-none tracking-tight truncate pr-6">
                {project.title}
              </CardTitle>
              <div className="z-10 relative">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="h-8 w-8 p-0">
                      <span className="sr-only">打开菜单</span>
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem
                      className="text-destructive focus:text-destructive"
                      onClick={(e) => {
                        e.stopPropagation() // Prevent card click
                        deleteProject(project.id)
                      }}
                    >
                      <Trash2 className="mr-2 h-4 w-4" />
                      移至回收站
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
            <CardDescription className="line-clamp-2 text-xs">{project.description || "无描述"}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="aspect-video w-full rounded-md bg-muted/50 object-cover" />
          </CardContent>
          <CardFooter>
            <p className="text-xs text-muted-foreground">
              更新于 {formatDistanceToNow(new Date(project.updated_at), { addSuffix: true, locale: zhCN })}
            </p>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}
