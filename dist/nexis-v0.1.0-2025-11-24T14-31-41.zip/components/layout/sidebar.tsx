"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import type { User } from "@/lib/db/schema"
import { signOut } from "@/app/actions/auth"
import { LayoutGrid, Trash2, Settings } from "lucide-react"

interface SidebarProps {
  user: User
}

export function Sidebar({ user }: SidebarProps) {
  const pathname = usePathname()

  const links = [
    { href: "/projects", label: "项目", icon: LayoutGrid },
    { href: "/projects/trash", label: "回收站", icon: Trash2 },
    { href: "/settings", label: "设置", icon: Settings },
  ]

  return (
    <div className="flex h-full w-64 flex-col border-r bg-card px-4 py-6">
      <div className="mb-8 flex items-center gap-2 px-2 font-bold text-xl">
        <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">N</div>
        Nexis
      </div>

      <nav className="flex-1 space-y-1">
        {links.map((link) => {
          const Icon = link.icon
          return (
            <Link
              key={link.href}
              href={link.href}
              className={cn(
                "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-muted",
                pathname === link.href ? "bg-muted text-foreground" : "text-muted-foreground"
              )}
            >
              <Icon className="h-4 w-4" />
              {link.label}
            </Link>
          )
        })}
      </nav>

      <div className="mt-auto border-t pt-4">
        <div className="flex items-center gap-3 px-2 py-2">
          <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center text-xs font-medium">
            {user.email?.[0].toUpperCase()}
          </div>
          <div className="flex flex-col overflow-hidden">
            <span className="truncate text-sm font-medium text-foreground">{user.email}</span>
          </div>
        </div>
        <form action={signOut}>
          <Button
            variant="ghost"
            className="w-full justify-start text-muted-foreground hover:text-foreground"
            size="sm"
          >
            退出登录
          </Button>
        </form>
      </div>
    </div>
  )
}
